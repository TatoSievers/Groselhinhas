import React, { useState, useRef, useEffect } from 'react';
import { SparklesIcon, XMarkIcon, PaperAirplaneIcon, ChevronDownIcon } from './Icons';
import { chatWithAssistant } from '../services/geminiService';
import Markdown from 'react-markdown';

interface Message {
  id: string;
  role: 'user' | 'model';
  parts: { text: string }[];
}

interface ChatAssistantProps {
  onMovieSelect?: (title: string) => void;
}

const INITIAL_TIPS = [
  "Posso te dar dicas de filmes baseadas no seu humor.",
  "Posso explicar sinopses de filmes complexos.",
  "Posso sugerir filmes parecidos com os seus favoritos.",
  "Posso te ajudar a escolher o que assistir hoje à noite.",
  "Me pergunte sobre curiosidades de bastidores de filmes!"
];

export const ChatAssistant: React.FC<ChatAssistantProps> = ({ onMovieSelect }) => {
  const [isOpen, setIsOpen] = useState(false);
  const [messages, setMessages] = useState<Message[]>(() => {
    const randomTip = INITIAL_TIPS[Math.floor(Math.random() * INITIAL_TIPS.length)];
    return [{
      id: '1',
      role: 'model',
      parts: [{ text: `{"intro": "Oi! Sou a CinAi, assistente do Groselhinhas. ${randomTip} O que vamos assistir hoje?", "accordions": []}` }]
    }];
  });
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [openAccordions, setOpenAccordions] = useState<Set<string>>(new Set());
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages, isOpen]);

  const handleSend = async () => {
    if (!input.trim() || isLoading) return;

    const userMessage: Message = {
      id: Date.now().toString(),
      role: 'user',
      parts: [{ text: input.trim() }]
    };

    const currentHistory = [...messages];
    setMessages(prev => [...prev, userMessage]);
    setInput('');
    setIsLoading(true);

    try {
      const responseText = await chatWithAssistant(userMessage.parts[0].text, currentHistory);
      
      const modelMessage: Message = {
        id: (Date.now() + 1).toString(),
        role: 'model',
        parts: [{ text: responseText }]
      };
      
      setMessages(prev => [...prev, modelMessage]);
    } catch (error) {
      console.error('Error in chat:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const toggleAccordion = (id: string) => {
    setOpenAccordions(prev => {
      const newSet = new Set(prev);
      if (newSet.has(id)) newSet.delete(id);
      else newSet.add(id);
      return newSet;
    });
  };

  const renderModelMessage = (text: string, messageId: string) => {
    try {
      const data = JSON.parse(text);
      return (
        <div className="space-y-3">
          {data.intro && (
            <div className="markdown-body">
              <Markdown>{data.intro}</Markdown>
            </div>
          )}
          
          {data.accordions && data.accordions.length > 0 && (
            <div className="space-y-2 mt-2">
              {data.accordions.map((acc: any, index: number) => {
                const accId = `${messageId}-${index}`;
                const isOpen = openAccordions.has(accId);
                return (
                  <div key={index} className="border border-white/10 rounded-xl overflow-hidden bg-black/20">
                    <button
                      onClick={() => toggleAccordion(accId)}
                      className="w-full flex items-center justify-between p-3 text-left hover:bg-white/5 transition-colors"
                    >
                      <span 
                        className="font-bold text-brand-accent hover:underline cursor-pointer"
                        onClick={(e) => {
                          e.stopPropagation();
                          if (onMovieSelect) {
                            onMovieSelect(acc.title);
                            setIsOpen(false);
                          }
                        }}
                      >
                        {acc.title}
                      </span>
                      <ChevronDownIcon className={`w-4 h-4 text-gray-400 transition-transform ${isOpen ? 'rotate-180' : ''}`} />
                    </button>
                    {isOpen && (
                      <div className="p-3 pt-0 border-t border-white/5 text-gray-300 text-sm markdown-body">
                        <Markdown>{acc.content}</Markdown>
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          )}

          {data.outro && (
            <div className="markdown-body mt-2">
              <Markdown>{data.outro}</Markdown>
            </div>
          )}
        </div>
      );
    } catch (e) {
      // Fallback to normal markdown if it's not valid JSON
      return (
        <div className="markdown-body">
          <Markdown>{text}</Markdown>
        </div>
      );
    }
  };

  return (
    <>
      {/* Floating Button */}
      {!isOpen && (
        <button
          onClick={() => setIsOpen(true)}
          className="fixed bottom-6 right-6 p-4 rounded-full bg-brand-accent text-brand-background shadow-xl shadow-amber-500/20 hover:scale-110 transition-transform z-50 flex items-center justify-center"
          aria-label="Abrir chat do assistente"
        >
          <SparklesIcon className="w-6 h-6" />
        </button>
      )}

      {/* Chat Window */}
      {isOpen && (
        <div className="fixed bottom-6 right-6 w-[350px] max-w-[calc(100vw-3rem)] h-[500px] max-h-[calc(100vh-6rem)] bg-gray-900/95 backdrop-blur-2xl border border-white/10 rounded-3xl shadow-2xl flex flex-col z-50 overflow-hidden animate-slide-up">
          {/* Header */}
          <div className="flex items-center justify-between px-6 py-4 border-b border-white/5 bg-black/20">
            <div className="flex items-center gap-2">
              <SparklesIcon className="w-5 h-5 text-brand-accent" />
              <h3 className="font-black italic text-white tracking-tight">CinAi</h3>
            </div>
            <button 
              onClick={() => setIsOpen(false)}
              className="p-2 rounded-full hover:bg-white/10 text-gray-400 hover:text-white transition-colors"
            >
              <XMarkIcon className="w-5 h-5" />
            </button>
          </div>

          {/* Messages */}
          <div className="flex-1 overflow-y-auto p-6 space-y-4 scrollbar-thin scrollbar-thumb-white/10 scrollbar-track-transparent">
            {messages.map((msg) => (
              <div 
                key={msg.id} 
                className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}
              >
                <div 
                  className={`max-w-[85%] rounded-2xl px-4 py-3 text-sm ${
                    msg.role === 'user' 
                      ? 'bg-brand-accent text-brand-background font-medium rounded-br-sm' 
                      : 'bg-white/5 text-gray-200 border border-white/5 rounded-bl-sm'
                  }`}
                >
                  {msg.role === 'user' ? (
                    msg.parts[0].text
                  ) : (
                    renderModelMessage(msg.parts[0].text, msg.id)
                  )}
                </div>
              </div>
            ))}
            {isLoading && (
              <div className="flex justify-start">
                <div className="bg-white/5 border border-white/5 rounded-2xl rounded-bl-sm px-4 py-4 flex gap-1.5">
                  <div className="w-1.5 h-1.5 bg-brand-accent/50 rounded-full animate-bounce" />
                  <div className="w-1.5 h-1.5 bg-brand-accent/50 rounded-full animate-bounce [animation-delay:0.2s]" />
                  <div className="w-1.5 h-1.5 bg-brand-accent/50 rounded-full animate-bounce [animation-delay:0.4s]" />
                </div>
              </div>
            )}
            <div ref={messagesEndRef} />
          </div>

          {/* Input */}
          <div className="p-4 border-t border-white/5 bg-black/20">
            <div className="relative flex items-center">
              <input
                type="text"
                value={input}
                onChange={(e) => setInput(e.target.value)}
                onKeyDown={(e) => e.key === 'Enter' && handleSend()}
                placeholder="Peça uma recomendação..."
                className="w-full bg-black/50 border border-white/10 rounded-full pl-5 pr-12 py-3 text-sm text-white placeholder-gray-500 focus:outline-none focus:border-brand-accent transition-colors"
              />
              <button
                onClick={handleSend}
                disabled={!input.trim() || isLoading}
                className="absolute right-2 p-2 rounded-full bg-brand-accent text-brand-background disabled:opacity-50 disabled:cursor-not-allowed hover:bg-amber-400 transition-colors"
              >
                <PaperAirplaneIcon className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>
      )}
    </>
  );
};
