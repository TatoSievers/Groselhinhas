import { GoogleGenAI, Type } from '@google/genai';

const ai = new GoogleGenAI({ apiKey: import.meta.env.VITE_GEMINI_API_KEY || process.env.GEMINI_API_KEY });

export const getMovieVibeCheck = async (title: string, synopsis: string): Promise<string> => {
  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3.1-flash-lite-preview',
      contents: `Analise a vibe do filme/série "${title}" com base nesta sinopse: "${synopsis}". Descreva a vibe em uma frase curta, impactante e moderna, usando emojis.`,
    });
    return response.text || 'Vibe misteriosa... ✨';
  } catch (error) {
    console.error('Error getting vibe check:', error);
    return 'Vibe indescritível no momento 🎬';
  }
};

export const chatWithAssistant = async (message: string, history: any[]): Promise<string> => {
  try {
    const ai = new GoogleGenAI({ apiKey: import.meta.env.VITE_GEMINI_API_KEY || process.env.GEMINI_API_KEY });
    
    const contents = history.map(msg => ({
      role: msg.role,
      parts: [{ text: msg.parts[0].text }]
    }));
    
    contents.push({ role: 'user', parts: [{ text: message }] });

    const response = await ai.models.generateContent({
      model: 'gemini-3.1-flash-lite-preview',
      contents: contents,
      config: {
        systemInstruction: `Você é o Cineasta IA, assistente do app "Groselhinhas".
Sempre responda em formato JSON.
O JSON deve ter a seguinte estrutura:
{
  "intro": "Mensagem introdutória curta",
  "accordions": [
    {
      "title": "Nome do Filme ou Tópico",
      "content": "Descrição detalhada, sinopse ou explicação em markdown."
    }
  ],
  "outro": "Mensagem final ou pergunta (opcional)"
}
Seja amigável, moderno e direto.`,
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            intro: { type: Type.STRING },
            accordions: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                properties: {
                  title: { type: Type.STRING },
                  content: { type: Type.STRING }
                },
                required: ["title", "content"]
              }
            },
            outro: { type: Type.STRING }
          },
          required: ["intro", "accordions"]
        }
      },
    });

    return response.text || '{"intro": "Desculpe, não consegui pensar em nada agora.", "accordions": []}';
  } catch (error) {
    console.error('Error chatting with assistant:', error);
    return '{"intro": "Desculpe, ocorreu um erro ao processar sua mensagem. Tente novamente mais tarde.", "accordions": []}';
  }
};
